Lesson videos for the Training page go here (<lesson>.mp4). They come in CoreWorkHub-training-videos.zip; rebuild them with: node scripts/record-training.cjs
