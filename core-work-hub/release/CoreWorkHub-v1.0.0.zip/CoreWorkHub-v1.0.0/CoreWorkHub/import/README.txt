Drop the hourly Service Desk export here as "Core - All.csv" (Setup\sync\Register-ExportCopyTask.ps1 does it for you). Any open hub imports it automatically when it changes.
