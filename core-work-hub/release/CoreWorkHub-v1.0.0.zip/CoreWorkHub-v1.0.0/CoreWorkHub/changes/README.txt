Each person's change file (<username>.jsonl) is created here by the hub. Do not edit or delete them: together they are the audit trail.
