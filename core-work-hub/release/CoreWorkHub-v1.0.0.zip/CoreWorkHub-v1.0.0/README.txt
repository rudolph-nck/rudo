Core Work Hub 1.0.0

Start with Setup\ADMIN-GUIDE.md. Copy the CoreWorkHub folder to the shared drive.
